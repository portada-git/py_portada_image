# py_portada_image
